#!/bin/sh
./longtest 0 &
./longtest 1 &
./longtest 2 &